# AURORA Clinician Dashboard: Prototype-Ready Visual Design Guidance

## TL;DR
- **Build a "clinical-utilitarian" interface that evokes Epic's *conventions* (persistent left storyboard, dense flat tables, red-reserved-for-critical flags, muted blue/gray chrome, system sans-serif with tabular numerals) rather than copying Epic's proprietary brand assets** — this delivers familiarity for US Epic sites while staying legally safe and genuinely usable for UK/LMIC sites who don't know Epic.
- **Use a system-font stack (Segoe UI/San Francisco/Roboto) at 13–14px table density with tabular lining numerals, on a very light gray (#F7F8FA) background with white cards**, and map the locked Wong colorblind-safe palette onto semantic roles — reserving a true red for crisis/urgent only, with icon + text + color on every status.
- **Diverge deliberately where it matters**: AI-provenance/confidence badges, the dual-track severity chart, and the two-tier alert system should look distinct and modern (EU AI Act transparency), while everything else reads as boring, fast, familiar clinical software.

## Key Findings

1. **Epic's actual type system is Segoe UI-based.** Epic's Hyperspace/Hyperdrive run on Windows and inherit Segoe UI. Per Microsoft Learn (Typography), "Segoe was designed by type designer Steve Matteson… It became Microsoft's default user interface font with the release of Windows Vista in 2007," a humanist sans-serif designed at Agfa Monotype that replaced Tahoma. This is directly replicable for free via the system-font stack, which resolves to Segoe UI on Windows — where nearly all US hospital Epic workstations run. (Note: Linotype has historically argued Segoe UI closely resembles its Frutiger family — the same typeface the NHS uses — meaning a system-font approach reads as familiar to *both* US-Epic and UK-NHS clinicians.)

2. **Epic's signature layout element is the "Storyboard"** — a persistent vertical left-rail panel that keeps patient demographics, allergies, problems, and alerts visible from every activity. It replaced the older horizontal patient banner via Epic version upgrades rolled out across major sites in 2019–2020 (e.g., UNC Health, Jan 26, 2020; WVU Medicine, Feb 2020; Yale/Northeast Medical Group, Sept 13, 2020). Per Northeast Medical Group: "Storyboard… redesigned the Epic workspace by replacing the patient header. Like the header, Storyboard follows the patient through the chart." This is the single most recognizable Epic convention and the highest-value one to evoke for AURORA's patient header.

3. **Red is reserved for critical across every authoritative source.** Epic flowsheets use a red triangle in the cell corner for abnormal values and red text/flags for critical labs; the EHRA "Design Patterns for Patient Safety" and the OSHA-aligned scheme in the 2025 *Applied Clinical Informatics* alert style guide (Pourian et al.) all converge: red = danger/immediate, orange = warning/act-but-not-urgent, yellow = caution/informational, blue = information.

4. **The locked Wong palette can be mapped onto an Epic-ish look without breaking red-reserved conventions** — but Wong's palette has no true red. Its vermillion (#D55E00) is the reddest option and should carry "off-track," with a dedicated deeper crisis red added only for the crisis/urgent state and the interruptive alert.

5. **NHS.UK provides a fully-specified, WCAG-tested open design system** with exact hex values — confirmed by the NHS digital service manual: text #212b32, blue #005eb8 (Pantone 300), red #d5281b, and grey-5 background #f0f4f5 (used "because the British Dyslexia Association's style guide recommends dark text on a light, but not white, background"). Its typeface is Frutiger, with Arial as the sanctioned fallback ("Please use Frutiger LT Std whenever possible. Arial can be used in the cases where the main font is not available"). Directly relevant for UK sites and a useful cross-check/fallback source of tested color tokens.

6. **Evidence-based specs converge on 13–14px dense tables, tabular lining numerals, sans-serif, non-white background, and "color never alone."** USWDS, the *Inspired EHRs* book (Belden et al.), the alert style guide, and multiple data-table typography sources all agree.

## Details

### A. Recommended Design-Token Starter Set

#### A.1 Typography

**Font stack (primary — zero web-font payload, renders as Epic-familiar Segoe UI on Windows):**
```
font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
             "Noto Sans", "Helvetica Neue", Arial, sans-serif;
```
- This resolves to **Segoe UI on Windows** (matching Epic), **San Francisco on macOS/iOS**, **Roboto on Android** (critical for LMIC low-end Android mobile parity), and **Noto Sans** as a broad-coverage fallback that fully supports Spanish diacritics and Bahasa Indonesia (Latin script). All support `tabular-nums`.
- **Rationale for system fonts over web fonts:** zero network payload matters for low-bandwidth/offline LMIC sites; a web font file is a real cost on slow connections. If a single brand font is mandated for cross-platform consistency, **Inter** or **Source Sans 3** are the best self-hosted fallbacks (both have tall x-heights, distinct 1/l/I/0/O glyphs, and tabular numerals; Source Sans 3 has superior Windows ClearType hinting at small sizes). NHS sites may substitute Frutiger where licensed (NHS England holds a perpetual license for 3 weights: Frutiger 45 Light, 55 Roman, 65 Bold).

**Tabular numerals (mandatory for all score/data columns and the chart):**
```
font-variant-numeric: tabular-nums lining-nums;
```
Apply globally to tables, the severity chart, PHQ-9/HAM-D score columns, timestamps, and any live-updating number to prevent column jitter and enable vertical digit scanning.

**Type scale (px; rem in parentheses assuming 16px root):**

| Token | Size | Weight | Line-height | Use |
|---|---|---|---|---|
| `text-xs` | 11px (0.6875rem) | 400/600 | 1.35 | Provenance/confidence micro-badges, data-completeness footnotes, timestamps |
| `text-sm` | 13px (0.8125rem) | 400 | 1.4 | **Dense table body rows, flowsheet cells** (density-optimal) |
| `text-base` | 14px (0.875rem) | 400 | 1.5 | Default UI text, form labels, patient-view body |
| `text-md` | 16px (1rem) | 400 | 1.5 | Reading passages (context-resolution card narrative) |
| `text-lg` | 18px (1.125rem) | 600 | 1.35 | Card titles, section headers |
| `text-xl` | 22px (1.375rem) | 600 | 1.3 | Patient name in header, view titles |
| `text-2xl` | 28px (1.75rem) | 700 | 1.25 | Print summary title only |

- Table headers: use the same size as body (13px) or +1px, at **weight 600 (SemiBold), not 700** — creates hierarchy with less visual noise per data-table typography research.
- **Never go below 12px** for anything a clinician must read; 11px reserved only for supplementary badges/footnotes that also carry an icon or full-text tooltip. The alert style guide (Pourian et al.) specifies 14pt optimal / 12pt acceptable for alerts specifically.
- **Bold only for emphasis** (never body); avoid ALL CAPS for readable strings (reduces legibility); no italics (accessibility + not licensed in NHS Frutiger).

#### A.2 Color Palette

**Neutral chrome (the "Epic-ish" muted blue/gray shell):**

| Token | Hex | Use |
|---|---|---|
| `chrome-header` | #1F4E79 | Top app bar / patient banner background (muted Epic-like deep blue) |
| `chrome-header-alt` | #2C6098 | Secondary nav / active tab |
| `rail-bg` | #EDF1F5 | Storyboard left-rail background |
| `page-bg` | #F7F8FA | App canvas background (very light gray, reduces glare vs pure white) |
| `card-bg` | #FFFFFF | Cards, tables, dialogs |
| `border` | #D8DDE0 | Table/card borders, dividers (matches NHS grey-4) |
| `row-hover` | #F0F4F5 | Table row hover (matches NHS grey-5) |
| `text-primary` | #212B32 | Body text (matches NHS text; ~13.6:1 on white) |
| `text-secondary` | #4C6272 | Labels, secondary text, timestamps (~7:1 on white, AAA) |
| `text-disabled` | #768692 | Placeholder/insufficient-data text |

**Semantic severity colors — the four-state taxonomy, reconciled with Wong + red-reserved:**

| Status | Icon (shape) | Text label | Fill/tint | Accent/border | Notes |
|---|---|---|---|---|---|
| **Crisis / Urgent** | ⛔ filled octagon / ⚠ filled triangle | "Crisis" / "Urgent" | #FCE9E6 | **#C0271A** (dedicated crisis red) | True red reserved ONLY here; Wong has no true red, so add a dedicated red for the most critical state |
| **Off-track** | ▲ filled triangle | "Off-track" | #FDF0E3 | **#D55E00** (Wong vermillion) | Warning tier |
| **Stable** | ● / ✓ filled circle | "Stable" | #E6F4EF | **#009E73** (Wong bluish-green) | Success tier |
| **Insufficient data** | ◐ half / — dash | "Insufficient data" | #EEF1F4 | **#768692** (neutral gray) | Never green; explicitly signals absence, not "OK" |

- **Informational/neutral accent:** #0072B2 (Wong blue) for links, selected states, informational badges, and the primary PHQ-9 chart line.
- **Every status uses icon + text + color simultaneously** (locked constraint); color is never the only signal.
- **Rationale for the dedicated crisis red (#C0271A):** Wong vermillion (#D55E00) reads as orange-red and is needed for "off-track"; layering a slightly deeper, unambiguous red on the crisis state preserves the universal red-reserved-for-critical convention that clinicians expect from Epic flowsheets and OSHA/EHRA conventions. Both #D55E00 and #C0271A remain distinguishable under deuteranopia/protanopia because they differ in lightness and are paired with distinct icon shapes (octagon vs triangle).

**PHQ-9 severity band background tints (subtle, utilitarian — for chart plot backgrounds):**

The bands map to the validated Kroenke et al. (2001) cut-points ("PHQ-9 scores of 5, 10, 15, and 20 represented mild, moderate, moderately severe, and severe depression, respectively," from a sample of 6,000 primary-care and 3,000 ob-gyn patients):

| Band | Score range | Tint hex |
|---|---|---|
| Minimal | 0–4 | #F2F7F4 |
| Mild | 5–9 | #FBF7E8 |
| Moderate | 10–14 | #FDF3E6 |
| Moderately severe | 15–19 | #FBEDE6 |
| Severe | 20–27 | #F7E6E3 |

- These are **desaturated (~6–10% saturation) horizontal bands** behind the time-series so the plot lines dominate. They provide instant severity context without shouting. Keep them lighter than any foreground data element.

**Chart line colors (dual-track severity time-series):**

| Series | Color | Style |
|---|---|---|
| PHQ-9 / HAM-D (clinician-administered) | #0072B2 (Wong blue) | Solid 2px line, filled circle markers |
| AI-COA AI-derived estimate | #E69F00 (Wong orange) | Solid 2px line, hollow diamond markers |
| AI-COA uncertainty band | #E69F00 @ 18% opacity | Filled area, no border |

- Blue vs orange is the single most robust colorblind-safe pair in the Wong palette (safe across all three CVD types). Distinct marker *shapes* (circle vs diamond) and line treatment ensure the two tracks separate even in grayscale.

#### A.3 Spacing, density, radii, elevation

- **Spacing scale (4px base grid):** 4, 8, 12, 16, 24, 32, 48px.
- **Table row height:** 32px (compact/flowsheet default) with 8px vertical cell padding; offer a 40px "comfortable" toggle. Compact density is the Epic-familiar default.
- **Border radius:** 4px on cards/inputs/buttons; 2px on table cells/badges; 0px acceptable for flowsheet grids (maximally utilitarian). Avoid large radii (>8px) — they read as consumer, not clinical.
- **Elevation/shadow policy:** Near-flat. Cards use a 1px #D8DDE0 border, not shadows. Reserve a single subtle shadow (`0 2px 8px rgba(0,0,0,0.12)`) exclusively for overlays: the interruptive crisis dialog, dropdowns, and tooltips. Skeuomorphism-free flat design.
- **Minimal animation:** ≤150ms functional transitions (hover, expand); no decorative motion. Respect `prefers-reduced-motion`.

### B. Component-by-Component Mapping (Epic/EHR convention → AURORA view)

| AURORA component | Epic/EHR analog | Design direction |
|---|---|---|
| **Caseload triage list** | Epic patient lists / schedule / track board / "My List" | Dense sortable table, 32px rows, row hover #F0F4F5, sortable column headers (SemiBold 13px), status badge in leftmost column (icon+text+color), sparkline column (single-color #0072B2, ~80×24px), last-contact timestamp, data-completeness micro-line. Filter chips above the table. Keyboard-navigable rows. |
| **Patient header / banner** | Epic **Storyboard** (persistent left rail) | Persistent left vertical rail (~260px): patient name (22px SemiBold), age/sex/ID, and — occupying Epic's **allergy-slot analog** — the **risk-state chip** (the four-state badge) as the visual anchor. Below: current PHQ-9 band, last assessment date, goals summary, data-completeness. Always visible across tabs. |
| **Dual-track severity chart** | Epic flowsheet trends / Synopsis graphs, but modernized | PHQ-9 band tints as plot background; blue clinician line + orange AI line + orange uncertainty band; tabular-nums axis labels; hover tooltip with provenance. This is a *deliberate divergence* — make it clearly more capable than a flowsheet graph. |
| **Context-resolution card** | Epic sidebar/summary report cards | White card, 1px border, 4px radius. Two-column: passive-sensing anomaly (left, with data-source provenance badge) paired with conversational explanation (right). 16px reading text for the narrative. |
| **Patient-defined goals** | Care plan / problem list items | Simple list with status icons; patient's own words in quotes; clinician annotation control inline. |
| **Clinician override / annotation** | Epic order/annotation + comment fields | Every AI output carries a persistent, visible "Override / Annotate" affordance (pencil icon + text). Overrides are logged, timestamped, attributed — shown as an inline provenance trail. Soft-stop confirmation (attestation click) not hard stop. |
| **Crisis alert (Tier 1)** | Epic **BPA pop-up (interruptive)** — "done right" | Modal, centered, single shadow, dedicated crisis red header (#C0271A) with ⛔ icon + "Crisis" text. Sans-serif 14pt. Intro text ≤2–3 sentences / ~30 words (per Pourian et al.). Patient identifier in same size as body (fires in-context). Max 2 bold emphases. Default action = require explicit clinician choice; allow documented opt-out with reason. NOT all-caps body. |
| **Deviation badge (Tier 2)** | Epic **abnormal-value flag** (red triangle / H-L flags) | Passive, non-interruptive inline badge on the row/value — triangle icon + short label + tint. Never a pop-up. Analogous to the red-corner-triangle flowsheet convention. |
| **Provenance / confidence / completeness** | (No strong Epic analog — deliberate divergence) | Small pill badges (11px, icon+text): e.g., "AI estimate" (blue), "Confidence: low" (with icon), "Data: 60% complete." Must stand out from clinical data per EU AI Act transparency — use the blue informational accent and a distinct pill shape. |
| **Printable session-prep summary** | Epic **After Visit Summary (AVS)** / print groups | Print-optimized layout: black text on white, bold section headers, page breaks between sections, larger font (12–14pt print), logical print groups. Three export variants (clinician / supervisor / patient) with role-appropriate content and reading level (patient variant ~6th–8th grade, per AVS best practice). Localized (EN/ES/ID). |

### C. Do-Replicate vs. Do-NOT-Replicate (from Epic)

**DO replicate (familiar conventions that work):**
- Persistent left storyboard/rail keeping patient context visible everywhere.
- Dense, sortable, hover-highlighted tables with compact row height.
- Red-reserved-for-critical + red-triangle/flag abnormal-value convention.
- Muted blue header chrome + gray/white body; flat, utilitarian aesthetic.
- Flowsheet-style grid for time-ordered data.
- Keyboard-first navigation; system font.
- Print/AVS conventions (bold section headers, print groups, role variants).
- Status/risk chip in the banner's "allergy-slot" position of prominence.

**Do NOT replicate (documented usability failures):**
- **Alert fatigue / over-firing interruptive BPAs** — Khairat et al., "Association of Electronic Health Record Use With Physician Fatigue and Efficiency," *JAMA Network Open* (June 9, 2020), studied 25 ICU physicians completing 4 simulated Epic ICU cases and found "All physician participants experienced physiological fatigue at least once during the exercise, and 20 of 25 participants (80%) experienced physiological fatigue within the first 22 minutes of EHR use" (36% within the first minute). Keep interruptive alerts to genuine crises only; everything else passive.
- **Excessive click depth / tab navigation burden** — a NewYork-Presbyterian/Weill Cornell/Columbia EpicCare transition study found persistent shortcomings in tab navigation and cognitive-burden reduction; keep AURORA's core workflow shallow (≤3 min, minimal clicks).
- **Visual clutter / "everything-at-once spreadsheet" density** — use whitespace and emphasis hierarchy; the *Inspired EHRs* principle is roughly three emphasized elements per screen (more than five is too many), not everything.
- **All-caps alert text, jarring color overuse.**
- **Inflexible print templates** that upgrades break (Federman et al. documented that Epic upgrades repeatedly rendered AVS redesigns non-functional; build AURORA's export cleanly from the start and decouple it from vendor templates).
- **Redundant/duplicated controls** (Inspired EHRs "removing complexity").

### D. Accessibility Verification Notes

- **Text contrast (WCAG 2.2 AA = 4.5:1 small text, 3:1 large/UI):**
  - #212B32 on #FFFFFF ≈ 13.6:1 (AAA). On #F7F8FA ≈ ~12.9:1 (AAA).
  - #4C6272 (secondary) on #FFFFFF ≈ 7:1 (AAA small).
  - White text on #1F4E79 header ≈ ~9:1 (AAA).
  - White text on #C0271A crisis red — verify ≈ 5.5:1 (passes AA); if borderline, darken the container or use larger/bold text.
  - #0072B2 on #FFFFFF ≈ 4.7:1 (passes AA small text) — safe for links.
- **Non-text/UI contrast:** status accent borders (#D55E00, #009E73, #C0271A) against white all exceed 3:1 for graphical objects; verify #009E73 (~2.9–3.0:1) — it is borderline for 3:1, so pair it with a darker 1px outline or use it only as a fill with a darker icon, not as a thin graphical line alone.
- **Color-blind simulation:** blue/orange chart pair is safe across protanopia/deuteranopia/tritanopia; crisis-red vs off-track-vermillion separated by lightness + icon shape (octagon vs triangle) + text — robust in grayscale. Run every screen through Color Oracle before shipping.
- **Minimum sizes:** body 14px, dense tables 13px, never <12px for required reading; touch targets ≥44×44px on mobile (LMIC parity); focus state a visible 2px outline (NHS uses #ffeb3b yellow focus — a strong, tested choice).
- **Color never sole signal:** enforced via icon+text+color on all four states and all badges.

### E. Localization & Performance Notes

- **System fonts = no web-font payload** → fastest first paint on low-bandwidth/offline LMIC sites; Roboto (Android) and Noto Sans fallback cover Spanish and Bahasa Indonesia Latin script fully.
- **Text expansion:** English→Spanish typically +15–30% (e.g., "FAQ"→"preguntas frecuentes"). Bahasa Indonesia often expands moderately too. Design all buttons, badges, chips, and table headers with `min-width` (not fixed width), flexible/auto-layout containers, a 30–50% expansion buffer on short strings, and multi-line wrapping. Test with pseudo-localization before real strings exist.
- **Diacritics:** Spanish (ñ, á, é, í, ó, ú, ü) and Indonesian Latin script render trivially in all recommended fonts.
- **Low-end Android rendering:** avoid font weights below 400 (thin weights disappear/alias badly on low-DPI Android + Chrome); use 400/600/700 only.
- **Offline tolerance:** since chrome uses system fonts and flat CSS (no heavy assets), the shell renders instantly; cache the palette/token CSS.
- **Timestamps:** store UTC, display local; use unambiguous format (e.g., "13 Aug 2026, 14:30") to avoid US/UK/LMIC date confusion.

### F. Familiarity vs. Distinctiveness Trade-off (per-country strategy)

- **US academic centers (Baylor, MGH — both Epic):** highest Epic familiarity; the storyboard rail, flat dense tables, and red-flag conventions will feel native and reduce novelty friction most here.
- **UK NHS trusts (SystmOne/EMIS + NHS.UK aesthetic):** know NHS visual language, not Epic; the NHS-derived neutral palette, Frutiger option, and clean government-service look bridge this. "Utilitarian clinical" generic conventions matter more than Epic mimicry. (The Segoe UI ≈ Frutiger resemblance means the same base type reads as familiar to both audiences.)
- **LMIC sites (Colombia, Bolivia, Paraguay, Peru, Indonesia):** may know neither Epic nor NHS; here **generic clinical-utilitarian clarity, mobile parity, low bandwidth, and localization matter far more than Epic resemblance.** Do not over-invest in Epic-specific mimicry at the expense of these.
- **Deliberate divergence for AI transparency (EU AI Act):** provenance/confidence badges, the dual-track AI chart, and override controls should look distinct and modern so AI-derived content is unmistakably flagged and never confused with clinician-entered data. This is a feature, not a bug — familiarity for the shell, distinctiveness for the AI.

## Recommendations

**Stage 1 — Build the token foundation (week 1):** Implement the system-font stack, the neutral chrome palette, the four-state semantic tokens, tabular-nums globally, and the 4px spacing grid as Figma variables + CSS custom properties. Verify all contrast pairs with the WebAIM checker before proceeding. *Threshold to proceed:* every text/background pair ≥4.5:1, every UI/graphic ≥3:1.

**Stage 2 — Prototype the two anchor views (weeks 2–3):** Caseload table + patient header (storyboard rail) with the dual-track chart. Run the 5-second glanceability test (can a clinician spot crisis patients instantly?) and the 3-minute workflow test with 3–5 clinicians per region. *Threshold to change:* if <90% correctly identify status at a glance, increase icon size/contrast or simplify the badge.

**Stage 3 — Alerts, provenance, and print (week 4):** Build the Tier-1 crisis modal (BPA-done-right spec above) and Tier-2 passive badges; the provenance/confidence badge system; and the three print export variants. Pilot alert firing rates. *Threshold:* if interruptive alerts fire more than ~1–2 per clinician-session in pilot, demote more to passive.

**Stage 4 — Localize and stress-test (weeks 5–6):** Pseudo-localize, then translate to ES/ID; test on a low-end Android device over throttled 3G; run Color Oracle CVD simulation on every screen. *Threshold to ship:* no layout breakage at +40% text expansion, first meaningful paint <3s on throttled connection.

**Cross-cutting:** Keep an "Epic-familiarity dial" — if usability testing shows US clinicians want *more* Epic resemblance, tighten the chrome blue and density; if UK/LMIC clinicians find it cluttered, relax density. Familiarity is a means (adoption), not the goal.

## Caveats

- **Epic's exact brand hex values, precise type sizes, and screen specs are proprietary** and behind Epic's UserWeb login; verified official Epic chrome hex values are not publicly available. The neutral-chrome hex values above are *reasoned approximations* of Epic's muted-blue/gray look, cross-validated against the openly-published NHS.UK palette — they are designed to *evoke*, not copy. This is intentional: **replicating Epic's trade dress too closely carries legal risk; evoking familiar generic clinical conventions does not** (high-level observation, not legal advice — have counsel review before launch).
- The Segoe UI = Epic connection is a strong inference (Epic runs on Windows and inherits the OS UI font) corroborated by Epic screenshots and by Microsoft's own documentation of Segoe UI as the Windows default; Epic has not published a public type spec confirming it.
- Contrast ratios marked "≈" and "verify" are calculated/estimated from the hex values and must be confirmed in a contrast checker during build; #009E73 as a thin line and white-on-crisis-red are the two combinations most likely to need adjustment.
- The alert style-guide specifications (14pt/12pt, ~30-word intro, OSHA red/orange/yellow, ≤2 bold emphases, no all-caps, default-to-choice) are from Pourian et al., "The Elements of Style for Interruptive Electronic Health Record Alerts," *Applied Clinical Informatics* 2025;16(2):402–408 (PMID 39740769), retrieved via cached full text (the live PMC/Thieme pages were bot-blocked); high confidence but not from a direct render.
- Wong palette hex values (Wong, *Nature Methods* 2011), PHQ-9 severity bands (Kroenke et al., *J Gen Intern Med* 2001), NHS hex tokens (NHS digital service manual), the Khairat et al. fatigue figures (*JAMA Network Open* 2020), and USWDS/data-table sizing are all from primary or authoritative sources and are solid.
- AURORA-specific components (context-resolution card, dual-track AI chart, provenance badges) have no direct Epic precedent, so those mappings are informed design proposals, not conventions to replicate.